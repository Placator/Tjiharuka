#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "utils.h"

/* Removes leftover characters from stdin after a bad scanf read,
   so the next read does not immediately fail on the same junk. */
void clearInputBuffer(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {
        /* discard */
    }
}

/* Reads an integer and keeps asking until the value is a real
   number within [min, max]. Used for menu choices etc. */
int getValidatedInt(const char *prompt, int min, int max) {
    int value;
    int valid = 0;

    do {
        printf("%s", prompt);

        if (scanf("%d", &value) != 1) {
            if (feof(stdin)) {
                printf("\nNo more input available. Exiting.\n");
                exit(0);
            }
            printf("Invalid input. Please enter a whole number.\n");
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        if (value < min || value > max) {
            printf("Please enter a value between %d and %d.\n", min, max);
        } else {
            valid = 1;
        }
    } while (!valid);

    return value;
}

/* Reads a float and keeps asking until it is numeric and not
   below 'min'. Used for money values that must not be negative. */
float getValidatedFloat(const char *prompt, float min) {
    float value;
    int valid = 0;

    do {
        printf("%s", prompt);

        if (scanf("%f", &value) != 1) {
            if (feof(stdin)) {
                printf("\nNo more input available. Exiting.\n");
                exit(0);
            }
            printf("Invalid input. Please enter a numeric value.\n");
            clearInputBuffer();
            continue;
        }
        clearInputBuffer();

        if (value < min) {
            printf("Value cannot be less than %.2f.\n", min);
        } else {
            valid = 1;
        }
    } while (!valid);

    return value;
}

/* Reads a line of text into buffer, strips the trailing newline,
   and rejects empty / whitespace-only input. */
void getValidatedString(const char *prompt, char *buffer, int size) {
    int valid = 0;

    do {
        printf("%s", prompt);

        if (fgets(buffer, size, stdin) == NULL) {
            printf("\nNo more input available. Exiting.\n");
            exit(0);
        }
        trimNewline(buffer);

        int hasContent = 0;
        for (int i = 0; buffer[i] != '\0'; i++) {
            if (!isspace((unsigned char)buffer[i])) {
                hasContent = 1;
                break;
            }
        }

        if (!hasContent) {
            printf("Input cannot be empty. Please try again.\n");
        } else {
            valid = 1;
        }
    } while (!valid);
}

/* Removes a trailing '\n' left behind by fgets(). */
void trimNewline(char *str) {
    size_t len = strlen(str);
    if (len > 0 && str[len - 1] == '\n') {
        str[len - 1] = '\0';
    }
}

/* Small pause so menu output does not scroll away instantly. */
void pause_screen(void) {
    printf("\nPress ENTER to continue...");
    getchar();
}
