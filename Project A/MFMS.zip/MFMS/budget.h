#ifndef BUDGET_H
#define BUDGET_H

/* ============================================================
   budget.h
   Budget Management module.
   Responsibility: departmental budgets, expenditure, remaining
   balance and over/under-budget status.
   ============================================================ */

#define MAX_BUDGETS 50
#define DEPT_LEN    50

typedef struct {
    char  department[DEPT_LEN];
    float allocatedBudget;
    float expenditure;
} Budget;

void  budgetMenu(Budget budgets[], int *count);
void  addBudget(Budget budgets[], int *count);
void  enterExpenditure(Budget budgets[], int count);
void  displayBudgets(const Budget budgets[], int count);
float calculateRemainingBudget(const Budget *b);
int   isWithinBudget(const Budget *b);
int   findBudgetIndex(const Budget budgets[], int count, const char *department);

#endif
