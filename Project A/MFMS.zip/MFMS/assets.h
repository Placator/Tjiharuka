#ifndef ASSETS_H
#define ASSETS_H

/* ============================================================
   assets.h
   Asset Management module.
   Responsibility: maintain a basic municipal asset register.
   ============================================================ */

#define MAX_ASSETS      100
#define ASSET_ID_LEN    20
#define ASSET_NAME_LEN  50
#define CONDITION_LEN   20

typedef struct {
    char  id[ASSET_ID_LEN];
    char  name[ASSET_NAME_LEN];
    char  type[ASSET_NAME_LEN];
    float purchaseValue;
    char  department[ASSET_NAME_LEN];
    char  condition[CONDITION_LEN];
} Asset;

void assetMenu(Asset assets[], int *count);
void addAsset(Asset assets[], int *count);
void displayAssets(const Asset assets[], int count);
void searchAsset(const Asset assets[], int count);
int  findAssetIndex(const Asset assets[], int count, const char *id);

#endif
