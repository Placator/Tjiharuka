#include <stdio.h>
#include <string.h>
#include "suppliers.h"
#include "utils.h"

void supplierMenu(Supplier suppliers[], int *count) {
    int choice;

    do {
        printf("\n========================================\n");
        printf("          SUPPLIER MANAGEMENT\n");
        printf("========================================\n");
        printf("1. Add Supplier\n");
        printf("2. Display All Suppliers\n");
        printf("3. Search Supplier\n");
        printf("4. Back to Main Menu\n");

        choice = getValidatedInt("Enter your choice: ", 1, 4);

        switch (choice) {
            case 1: addSupplier(suppliers, count);        break;
            case 2: displaySuppliers(suppliers, *count);  break;
            case 3: searchSupplier(suppliers, *count);    break;
            case 4: printf("Returning to Main Menu...\n"); break;
        }
    } while (choice != 4);
}

void addSupplier(Supplier suppliers[], int *count) {
    if (*count >= MAX_SUPPLIERS) {
        printf("Supplier list is full. Cannot add more suppliers.\n");
        return;
    }

    Supplier newSup;

    getValidatedString("Enter Supplier ID: ", newSup.id, SUP_ID_LEN);

    if (findSupplierIndex(suppliers, *count, newSup.id) != -1) {
        printf("A supplier with ID '%s' already exists.\n", newSup.id);
        return;
    }

    getValidatedString("Enter Supplier Name: ", newSup.name, SUP_NAME_LEN);
    getValidatedString("Enter Email: ", newSup.email, SUP_NAME_LEN);
    getValidatedString("Enter Telephone Number: ", newSup.phone, PHONE_LEN);
    getValidatedString("Enter Town/Location: ", newSup.location, SUP_NAME_LEN);

    suppliers[*count] = newSup;
    (*count)++;

    printf("Supplier '%s' added successfully.\n", newSup.name);
}

int findSupplierIndex(const Supplier suppliers[], int count, const char *id) {
    for (int i = 0; i < count; i++) {
        if (strcmp(suppliers[i].id, id) == 0) {
            return i;
        }
    }
    return -1;
}

void displaySuppliers(const Supplier suppliers[], int count) {
    if (count == 0) {
        printf("No suppliers have been recorded yet.\n");
        return;
    }

    printf("\n%-10s %-20s %-25s %-15s %-15s\n",
           "ID", "Name", "Email", "Phone", "Location");
    printf("-----------------------------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        printf("%-10s %-20s %-25s %-15s %-15s\n",
               suppliers[i].id, suppliers[i].name, suppliers[i].email,
               suppliers[i].phone, suppliers[i].location);
    }
}

void searchSupplier(const Supplier suppliers[], int count) {
    if (count == 0) {
        printf("No suppliers have been recorded yet.\n");
        return;
    }

    char searchId[SUP_ID_LEN];
    getValidatedString("Enter Supplier ID to search: ", searchId, SUP_ID_LEN);

    int index = findSupplierIndex(suppliers, count, searchId);

    if (index == -1) {
        printf("No supplier found with ID '%s'.\n", searchId);
        return;
    }

    Supplier sup = suppliers[index];

    printf("\n---- SUPPLIER FOUND ----\n");
    printf("ID:       %s\n", sup.id);
    printf("Name:     %s\n", sup.name);
    printf("Email:    %s\n", sup.email);
    printf("Phone:    %s\n", sup.phone);
    printf("Location: %s\n", sup.location);
}
