# Municipal Financial Management System (MFMS)

**Course:** PAP521S – Programming in Practice
**Group Number:** _[insert your group number]_
**Project:** Project A – Foundation System
**Programming Language:** ANSI C (C99)

## Group Members

| Student Name | Student Number | Responsibility |
|---|---|---|
| _[Name]_ | _[Number]_ | Employee Management |
| _[Name]_ | _[Number]_ | Budget Management |
| _[Name]_ | _[Number]_ | Supplier Management |
| _[Name]_ | _[Number]_ | Asset Management |
| _[Name]_ | _[Number]_ | Reports |
| _[Name]_ | _[Number]_ | Functions, Integration and Validation |
| _[Name]_ | _[Number]_ | Testing, Documentation and Git Coordination |

> Fill in your group's details above before submitting. If you are completing this individually, list yourself against every responsibility and note that in your report.

## Project Description

MFMS is a menu-driven, console-based system built for a municipality to manage its core
financial and administrative records. This is the **foundation version** (Project A) of the
system, covering employee records, departmental budgets, suppliers, and a basic asset
register, with reporting across all four areas. Project B will extend this foundation.

## System Features

- **Employee Management** – add, display, and search employees; calculates gross salary
  (basic + housing allowance + transport allowance) for each employee.
- **Budget Management** – capture a department's allocated budget, record expenditure
  against it, and automatically determine WITHIN BUDGET / OVER BUDGET status.
- **Supplier Management** – register, display, and search municipal suppliers by ID.
- **Asset Management** – maintain a basic register of municipal assets (vehicles,
  computers, buildings, equipment, furniture) with condition and department.
- **Reports** – employee report (total, average, highest, lowest salary), budget report
  (totals and departments over budget), supplier report, and asset report (with total
  asset value).
- **Input Validation** – rejects negative money values, empty names, and invalid menu
  choices; re-prompts the user instead of crashing.

## Project Structure

```
MFMS/
├── main.c          # Program entry point and main menu
├── employees.c/h    # Employee Management module
├── budget.c/h        # Budget Management module
├── suppliers.c/h      # Supplier Management module
├── assets.c/h          # Asset Management module
├── reports.c/h          # Reports module (reads data from all other modules)
├── utils.c/h             # Shared input-validation helper functions
└── README.md
```

Each module exposes a `xxxMenu()` function that main.c calls. All record arrays and their
counts are declared once in `main()` and passed into modules by reference (pointer to the
count variable), so every module works on the same shared data without using global
variables.

## Compilation Instructions

This project uses only the C standard library, so it compiles with any ANSI C99 compiler
(GCC recommended) and has no external dependencies.

**Using GCC directly:**

```bash
gcc -std=c99 -Wall -Wextra -o mfms main.c employees.c budget.c suppliers.c assets.c reports.c utils.c
```

**Using VS Code:** open the folder, then run the command above in the integrated terminal
(Terminal → New Terminal).

## How to Run the System

After compiling, run the produced executable:

```bash
./mfms          # Linux / macOS
mfms.exe        # Windows
```

You will see the main menu:

```
========================================
MUNICIPAL FINANCIAL MANAGEMENT SYSTEM
========================================
1. Employee Management
2. Budget Management
3. Supplier Management
4. Asset Management
5. Reports
6. Exit
Enter your choice:
```

Enter a number from 1–6 and follow the on-screen prompts. Each module has its own
sub-menu with an option to return to the Main Menu, and the Main Menu has an Exit option.

## Individual Responsibilities

See the Group Members table above. Each member's contribution should also be recorded
separately in the **Individual Contribution Record** submitted alongside this project, and
should be visible as commits in this repository's Git history.

## Notes for Project B

This foundation intentionally uses fixed-size arrays and in-memory storage only (no file
persistence), matching the Week 1–8 course scope (arrays, strings, functions, no
file I/O or dynamic memory). Project B is expected to extend this design rather than
replace it — for example by adding file saving/loading, dynamic memory, or more advanced
data structures, while keeping the same module boundaries established here.
