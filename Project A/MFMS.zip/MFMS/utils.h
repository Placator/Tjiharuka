#ifndef UTILS_H
#define UTILS_H

/* ============================================================
   utils.h
   Shared input-validation and helper functions used across all
   modules (employees, budget, suppliers, assets, reports).
   Keeping these in one place avoids duplicating validation
   logic in every module.
   ============================================================ */

void clearInputBuffer(void);
int  getValidatedInt(const char *prompt, int min, int max);
float getValidatedFloat(const char *prompt, float min);
void getValidatedString(const char *prompt, char *buffer, int size);
void trimNewline(char *str);
void pause_screen(void);

#endif
