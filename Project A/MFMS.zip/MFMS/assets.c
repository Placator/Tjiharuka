#include <stdio.h>
#include <string.h>
#include "assets.h"
#include "utils.h"

void assetMenu(Asset assets[], int *count) {
    int choice;

    do {
        printf("\n========================================\n");
        printf("            ASSET MANAGEMENT\n");
        printf("========================================\n");
        printf("1. Add Asset\n");
        printf("2. Display All Assets\n");
        printf("3. Search Asset\n");
        printf("4. Back to Main Menu\n");

        choice = getValidatedInt("Enter your choice: ", 1, 4);

        switch (choice) {
            case 1: addAsset(assets, count);        break;
            case 2: displayAssets(assets, *count);  break;
            case 3: searchAsset(assets, *count);    break;
            case 4: printf("Returning to Main Menu...\n"); break;
        }
    } while (choice != 4);
}

void addAsset(Asset assets[], int *count) {
    if (*count >= MAX_ASSETS) {
        printf("Asset register is full. Cannot add more assets.\n");
        return;
    }

    Asset newAsset;

    getValidatedString("Enter Asset ID: ", newAsset.id, ASSET_ID_LEN);

    if (findAssetIndex(assets, *count, newAsset.id) != -1) {
        printf("An asset with ID '%s' already exists.\n", newAsset.id);
        return;
    }

    getValidatedString("Enter Asset Name: ", newAsset.name, ASSET_NAME_LEN);
    getValidatedString("Enter Asset Type (e.g. Vehicle, Computer): ", newAsset.type, ASSET_NAME_LEN);
    newAsset.purchaseValue = getValidatedFloat("Enter Purchase Value: N$", 0.0f);
    getValidatedString("Enter Department: ", newAsset.department, ASSET_NAME_LEN);
    getValidatedString("Enter Condition (e.g. New, Good, Fair, Poor): ", newAsset.condition, CONDITION_LEN);

    assets[*count] = newAsset;
    (*count)++;

    printf("Asset '%s' added successfully.\n", newAsset.name);
}

int findAssetIndex(const Asset assets[], int count, const char *id) {
    for (int i = 0; i < count; i++) {
        if (strcmp(assets[i].id, id) == 0) {
            return i;
        }
    }
    return -1;
}

void displayAssets(const Asset assets[], int count) {
    if (count == 0) {
        printf("No assets have been recorded yet.\n");
        return;
    }

    printf("\n%-10s %-20s %-15s %-12s %-15s %-10s\n",
           "ID", "Name", "Type", "Value", "Department", "Condition");
    printf("---------------------------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        printf("%-10s %-20s %-15s %-12.2f %-15s %-10s\n",
               assets[i].id, assets[i].name, assets[i].type,
               assets[i].purchaseValue, assets[i].department, assets[i].condition);
    }
}

void searchAsset(const Asset assets[], int count) {
    if (count == 0) {
        printf("No assets have been recorded yet.\n");
        return;
    }

    char searchId[ASSET_ID_LEN];
    getValidatedString("Enter Asset ID to search: ", searchId, ASSET_ID_LEN);

    int index = findAssetIndex(assets, count, searchId);

    if (index == -1) {
        printf("No asset found with ID '%s'.\n", searchId);
        return;
    }

    Asset a = assets[index];

    printf("\n---- ASSET FOUND ----\n");
    printf("ID:             %s\n", a.id);
    printf("Name:           %s\n", a.name);
    printf("Type:           %s\n", a.type);
    printf("Purchase Value: N$%.2f\n", a.purchaseValue);
    printf("Department:     %s\n", a.department);
    printf("Condition:      %s\n", a.condition);
}
