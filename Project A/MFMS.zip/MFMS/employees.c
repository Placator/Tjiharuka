#include <stdio.h>
#include <string.h>
#include "employees.h"
#include "utils.h"

/* Sub-menu for the Employee Management module.
   The array and its current count are passed by reference
   (pointer to count) so this module can grow the array that
   actually lives in main(). */
void employeeMenu(Employee employees[], int *count) {
    int choice;

    do {
        printf("\n========================================\n");
        printf("          EMPLOYEE MANAGEMENT\n");
        printf("========================================\n");
        printf("1. Add Employee\n");
        printf("2. Display All Employees\n");
        printf("3. Search Employee\n");
        printf("4. Back to Main Menu\n");

        choice = getValidatedInt("Enter your choice: ", 1, 4);

        switch (choice) {
            case 1: addEmployee(employees, count);        break;
            case 2: displayEmployees(employees, *count);  break;
            case 3: searchEmployee(employees, *count);    break;
            case 4: printf("Returning to Main Menu...\n"); break;
        }
    } while (choice != 4);
}

void addEmployee(Employee employees[], int *count) {
    if (*count >= MAX_EMPLOYEES) {
        printf("Employee list is full. Cannot add more employees.\n");
        return;
    }

    Employee newEmp;

    getValidatedString("Enter Employee ID: ", newEmp.id, ID_LEN);

    /* strcmp() used here to stop duplicate Employee IDs */
    if (findEmployeeIndex(employees, *count, newEmp.id) != -1) {
        printf("An employee with ID '%s' already exists.\n", newEmp.id);
        return;
    }

    getValidatedString("Enter Employee Name: ", newEmp.name, NAME_LEN);
    getValidatedString("Enter Department: ", newEmp.department, NAME_LEN);

    newEmp.basicSalary         = getValidatedFloat("Enter Basic Salary: N$", 0.0f);
    newEmp.housingAllowance    = getValidatedFloat("Enter Housing Allowance: N$", 0.0f);
    newEmp.transportAllowance  = getValidatedFloat("Enter Transport Allowance: N$", 0.0f);

    employees[*count] = newEmp;
    (*count)++;

    printf("Employee '%s' added successfully.\n", newEmp.name);
}

/* Gross salary = basic + housing allowance + transport allowance. */
float calculateGrossSalary(const Employee *emp) {
    return emp->basicSalary + emp->housingAllowance + emp->transportAllowance;
}

void displayEmployees(const Employee employees[], int count) {
    if (count == 0) {
        printf("No employees have been recorded yet.\n");
        return;
    }

    printf("\n%-10s %-20s %-15s %-10s %-10s %-10s %-10s\n",
           "ID", "Name", "Department", "Basic", "Housing", "Transport", "Gross");
    printf("---------------------------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        float gross = calculateGrossSalary(&employees[i]);
        printf("%-10s %-20s %-15s %-10.2f %-10.2f %-10.2f %-10.2f\n",
               employees[i].id, employees[i].name, employees[i].department,
               employees[i].basicSalary, employees[i].housingAllowance,
               employees[i].transportAllowance, gross);
    }
}

/* Linear search by Employee ID using strcmp(). Returns the index
   of the match, or -1 if no employee has that ID. */
int findEmployeeIndex(const Employee employees[], int count, const char *id) {
    for (int i = 0; i < count; i++) {
        if (strcmp(employees[i].id, id) == 0) {
            return i;
        }
    }
    return -1;
}

void searchEmployee(const Employee employees[], int count) {
    if (count == 0) {
        printf("No employees have been recorded yet.\n");
        return;
    }

    char searchId[ID_LEN];
    getValidatedString("Enter Employee ID to search: ", searchId, ID_LEN);

    int index = findEmployeeIndex(employees, count, searchId);

    if (index == -1) {
        printf("No employee found with ID '%s'.\n", searchId);
        return;
    }

    Employee emp = employees[index];
    float gross = calculateGrossSalary(&emp);

    printf("\n---- EMPLOYEE FOUND ----\n");
    printf("ID:                  %s\n", emp.id);
    printf("Name:                %s\n", emp.name);
    printf("Department:          %s\n", emp.department);
    printf("Basic Salary:        N$%.2f\n", emp.basicSalary);
    printf("Housing Allowance:   N$%.2f\n", emp.housingAllowance);
    printf("Transport Allowance: N$%.2f\n", emp.transportAllowance);
    printf("Gross Salary:        N$%.2f\n", gross);
}
