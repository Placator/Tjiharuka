#include <stdio.h>
#include "reports.h"
#include "utils.h"

void reportsMenu(const Employee employees[], int employeeCount,
                  const Budget budgets[], int budgetCount,
                  const Supplier suppliers[], int supplierCount,
                  const Asset assets[], int assetCount) {
    int choice;

    do {
        printf("\n========================================\n");
        printf("                REPORTS\n");
        printf("========================================\n");
        printf("1. Employee Report\n");
        printf("2. Budget Report\n");
        printf("3. Supplier Report\n");
        printf("4. Asset Report\n");
        printf("5. Back to Main Menu\n");

        choice = getValidatedInt("Enter your choice: ", 1, 5);

        switch (choice) {
            case 1: employeeReport(employees, employeeCount); break;
            case 2: budgetReport(budgets, budgetCount);        break;
            case 3: supplierReport(suppliers, supplierCount);  break;
            case 4: assetReport(assets, assetCount);           break;
            case 5: printf("Returning to Main Menu...\n");     break;
        }
    } while (choice != 5);
}

/* Total, average, highest and lowest gross salary, calculated
   with a single pass (loop) over the employee array. */
void employeeReport(const Employee employees[], int count) {
    printf("\n---- EMPLOYEE REPORT ----\n");

    if (count == 0) {
        printf("No employees have been recorded yet.\n");
        return;
    }

    float total = 0.0f;
    float highest = calculateGrossSalary(&employees[0]);
    float lowest = highest;

    for (int i = 0; i < count; i++) {
        float gross = calculateGrossSalary(&employees[i]);
        total += gross;

        if (gross > highest) highest = gross;
        if (gross < lowest)  lowest = gross;
    }

    float average = total / count;

    printf("Total Employees: %d\n", count);
    printf("Average Salary:  N$%.2f\n", average);
    printf("Highest Salary:  N$%.2f\n", highest);
    printf("Lowest Salary:   N$%.2f\n", lowest);
}

/* Total allocated, total spent, total remaining, and a list of
   departments whose expenditure has exceeded their allocation. */
void budgetReport(const Budget budgets[], int count) {
    printf("\n---- BUDGET REPORT ----\n");

    if (count == 0) {
        printf("No departmental budgets have been recorded yet.\n");
        return;
    }

    float totalAllocated = 0.0f;
    float totalExpenditure = 0.0f;

    for (int i = 0; i < count; i++) {
        totalAllocated   += budgets[i].allocatedBudget;
        totalExpenditure += budgets[i].expenditure;
    }

    printf("Total Allocated Budget: N$%.2f\n", totalAllocated);
    printf("Total Expenditure:      N$%.2f\n", totalExpenditure);
    printf("Total Remaining Budget: N$%.2f\n", totalAllocated - totalExpenditure);

    printf("\nDepartments Exceeding Budget:\n");
    int overCount = 0;

    for (int i = 0; i < count; i++) {
        if (!isWithinBudget(&budgets[i])) {
            printf(" - %s (Over by N$%.2f)\n",
                   budgets[i].department,
                   budgets[i].expenditure - budgets[i].allocatedBudget);
            overCount++;
        }
    }

    if (overCount == 0) {
        printf(" None. All departments are within budget.\n");
    }
}

void supplierReport(const Supplier suppliers[], int count) {
    printf("\n---- SUPPLIER REPORT ----\n");
    printf("Total Suppliers Registered: %d\n", count);
    displaySuppliers(suppliers, count);
}

void assetReport(const Asset assets[], int count) {
    printf("\n---- ASSET REPORT ----\n");
    printf("Total Assets Registered: %d\n", count);

    float totalValue = 0.0f;
    for (int i = 0; i < count; i++) {
        totalValue += assets[i].purchaseValue;
    }
    printf("Total Asset Value: N$%.2f\n", totalValue);

    displayAssets(assets, count);
}
