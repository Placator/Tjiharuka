#include <stdio.h>
#include <string.h>
#include "budget.h"
#include "utils.h"

void budgetMenu(Budget budgets[], int *count) {
    int choice;

    do {
        printf("\n========================================\n");
        printf("           BUDGET MANAGEMENT\n");
        printf("========================================\n");
        printf("1. Enter Departmental Budget\n");
        printf("2. Enter Expenditure\n");
        printf("3. Display Budgets\n");
        printf("4. Back to Main Menu\n");

        choice = getValidatedInt("Enter your choice: ", 1, 4);

        switch (choice) {
            case 1: addBudget(budgets, count);          break;
            case 2: enterExpenditure(budgets, *count);  break;
            case 3: displayBudgets(budgets, *count);    break;
            case 4: printf("Returning to Main Menu...\n"); break;
        }
    } while (choice != 4);
}

void addBudget(Budget budgets[], int *count) {
    if (*count >= MAX_BUDGETS) {
        printf("Budget list is full. Cannot add more departments.\n");
        return;
    }

    Budget newBudget;
    getValidatedString("Enter Department Name: ", newBudget.department, DEPT_LEN);

    if (findBudgetIndex(budgets, *count, newBudget.department) != -1) {
        printf("A budget for department '%s' already exists.\n", newBudget.department);
        return;
    }

    newBudget.allocatedBudget = getValidatedFloat("Enter Allocated Budget: N$", 0.0f);
    newBudget.expenditure = 0.0f;   /* expenditure starts at zero */

    budgets[*count] = newBudget;
    (*count)++;

    printf("Budget for '%s' added successfully.\n", newBudget.department);
}

/* Linear search for a department's budget record by name. */
int findBudgetIndex(const Budget budgets[], int count, const char *department) {
    for (int i = 0; i < count; i++) {
        if (strcmp(budgets[i].department, department) == 0) {
            return i;
        }
    }
    return -1;
}

void enterExpenditure(Budget budgets[], int count) {
    if (count == 0) {
        printf("No departmental budgets have been recorded yet.\n");
        return;
    }

    char dept[DEPT_LEN];
    getValidatedString("Enter Department Name: ", dept, DEPT_LEN);

    int index = findBudgetIndex(budgets, count, dept);
    if (index == -1) {
        printf("No budget found for department '%s'.\n", dept);
        return;
    }

    float amount = getValidatedFloat("Enter Expenditure Amount: N$", 0.0f);
    budgets[index].expenditure += amount;

    printf("Expenditure of N$%.2f recorded for '%s'.\n", amount, dept);
}

float calculateRemainingBudget(const Budget *b) {
    return b->allocatedBudget - b->expenditure;
}

/* A department is within budget while expenditure has not
   exceeded what was allocated to it. */
int isWithinBudget(const Budget *b) {
    return b->expenditure <= b->allocatedBudget;
}

void displayBudgets(const Budget budgets[], int count) {
    if (count == 0) {
        printf("No departmental budgets have been recorded yet.\n");
        return;
    }

    printf("\n%-20s %-15s %-15s %-15s %-15s\n",
           "Department", "Allocated", "Expenditure", "Remaining", "Status");
    printf("---------------------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        float remaining = calculateRemainingBudget(&budgets[i]);
        const char *status = isWithinBudget(&budgets[i]) ? "WITHIN BUDGET" : "OVER BUDGET";

        printf("%-20s %-15.2f %-15.2f %-15.2f %-15s\n",
               budgets[i].department, budgets[i].allocatedBudget,
               budgets[i].expenditure, remaining, status);
    }
}
