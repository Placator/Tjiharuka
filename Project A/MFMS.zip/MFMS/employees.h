#ifndef EMPLOYEES_H
#define EMPLOYEES_H

/* ============================================================
   employees.h
   Employee Management module.
   Responsibility: add, display, search employees and calculate
   salary information.
   ============================================================ */

#define MAX_EMPLOYEES 100
#define ID_LEN        20
#define NAME_LEN      50

typedef struct {
    char id[ID_LEN];
    char name[NAME_LEN];
    char department[NAME_LEN];
    float basicSalary;
    float housingAllowance;
    float transportAllowance;
} Employee;

void  employeeMenu(Employee employees[], int *count);
void  addEmployee(Employee employees[], int *count);
void  displayEmployees(const Employee employees[], int count);
void  searchEmployee(const Employee employees[], int count);
float calculateGrossSalary(const Employee *emp);
int   findEmployeeIndex(const Employee employees[], int count, const char *id);

#endif
