#ifndef SUPPLIERS_H
#define SUPPLIERS_H

/* ============================================================
   suppliers.h
   Supplier Management module.
   Responsibility: register, display and search municipal
   suppliers.
   ============================================================ */

#define MAX_SUPPLIERS 100
#define SUP_ID_LEN    20
#define SUP_NAME_LEN  50
#define PHONE_LEN     20

typedef struct {
    char id[SUP_ID_LEN];
    char name[SUP_NAME_LEN];
    char email[SUP_NAME_LEN];
    char phone[PHONE_LEN];
    char location[SUP_NAME_LEN];
} Supplier;

void supplierMenu(Supplier suppliers[], int *count);
void addSupplier(Supplier suppliers[], int *count);
void displaySuppliers(const Supplier suppliers[], int count);
void searchSupplier(const Supplier suppliers[], int count);
int  findSupplierIndex(const Supplier suppliers[], int count, const char *id);

#endif
